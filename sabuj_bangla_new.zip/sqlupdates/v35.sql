UPDATE `business_settings` SET `value` = '3.5' WHERE `business_settings`.`type` = 'current_version';

COMMIT;
