UPDATE `business_settings` SET `value` = '7.6.0' WHERE `business_settings`.`type` = 'current_version';

COMMIT;