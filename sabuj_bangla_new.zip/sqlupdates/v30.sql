UPDATE `business_settings` SET `value` = '3.0' WHERE `business_settings`.`type` = 'current_version';

COMMIT;
