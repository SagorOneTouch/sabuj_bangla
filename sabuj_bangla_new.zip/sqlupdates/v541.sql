UPDATE `business_settings` SET `value` = '5.4.1' WHERE `business_settings`.`type` = 'current_version';

COMMIT;