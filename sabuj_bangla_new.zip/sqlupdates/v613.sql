UPDATE `business_settings` SET `value` = '6.1.3' WHERE `business_settings`.`type` = 'current_version';

COMMIT;